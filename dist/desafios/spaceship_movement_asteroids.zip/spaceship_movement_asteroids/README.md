# Desafío: Spaceship movement

El desafío consiste nada menos que en clonar el movimiento de la nave de un juego similar al clásico Asteroids.

En la carpeta *demo* se puede ver cómo debería ser el movimiento (no es necesario que la nave ingrese por el otro lado de la pantalla al salir).

El código se debe escribir en el archivo correspondiente a la clase de la nave: *Ship.hx*.