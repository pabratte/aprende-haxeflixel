# Desafío: Animated character

El desafío consiste en animar el personaje para que se mueva de la misma forma que el ejemplo de la carpeta *demo*.

Tener en cuenta:

* El personaje sólo debe admitir movimientos en una dirección a la vez (NO en diagonal)
* El personaje debe quedar mirando hacia el último lado al que se movió